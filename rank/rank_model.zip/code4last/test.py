# SE模块
def SeBlock():