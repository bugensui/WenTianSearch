



cd ..

# 创建保存排序模型的的文件夹
output_dir="./output"
mkdir $output
mkdir $output/epoch
mkdir $output/best_loss
mkdir $output/best_mrr
mkdir $output/last
mkdir $output/best_model


# 训练排序模型
python train.py \
    --bert_model_path ./bert_pretrain/bert/tmp/best_model/model.ckpt-46000 \
    --bert_config_path ./bert_pretrain/model4bert/bert_config.json \
    --bert_vocab_path ./bert_pretrain/model4bert/vocab.txt \
    --output_dir $output \
    --learning_rate 3e-5 \
    --batch_size 64 \
    --num_epochs 3 \
    --warmup_proportion 0.01 \
    --max_seq_length 128 \
    --save_steps 5000 \
    --eval_steps 50000 \
    --query_ids_file_path ./data4rank/train.query.json \
    --trainset_dir ./data4rank/0515_14_20_50 \
    --corpus_ids_file_path ./data4rank/corpus.json \
    --dev_ids_file_path ./data/data_dev_ids


# 提交第二个epoch结束后保存的结果
cp $output/epoch/epoch1_models-100.* $output/best_model/


# 打包到指定文件夹
python wrapper.py \
    --bert_config_path ./bert_pretrain/model4bert/bert_config.json \
    --ckpt_to_convert $output/best_model/epoch1_models-100 \
    --output_dir $output/best_model/wrapper \
    --max_seq_length 128

